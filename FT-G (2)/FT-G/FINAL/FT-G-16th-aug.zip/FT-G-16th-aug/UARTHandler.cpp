#include "UARTHandler.h"
#include "MotorControl.h"
#include <string.h>

#define BUFFER_SIZE 200

uint8_t commandBuffer[BUFFER_SIZE];
volatile int idx = 0;
char *c = NULL;
uint8_t index = 0;

const uint8_t StartButton[] = { 0x5A, 0xA5, 0x06, 0x83, 0x10, 0x12, 0x01, 0x00, 0x01, 0x00 };
const uint8_t StopButton[] = { 0x5A, 0xA5, 0x06, 0x83, 0x10, 0x14, 0x01, 0x00, 0x01, 0x00 };
const uint8_t SetSec[] = { 0x10, 0x08, 0x00 };
const uint8_t SetMin[] = { 0x0F, 0xFF, 0x00 };
const uint8_t GotoStop[] = { 0x5A, 0xA5, 0x07, 0x82, 0x00, 0x84, 0x5A, 0x01, 0x00, 0x01 };  // 5A A5 07 82 00 84 5A 01 00 XX
const uint8_t GotoStart[] = { 0x5A, 0xA5, 0x07, 0x82, 0x00, 0x84, 0x5A, 0x01, 0x00, 0x00 };

const size_t GotoStartSize = sizeof(GotoStart);
volatile int statements = 0;
uint8_t homePage_setSec = 0;
uint8_t homePage_setMin = 0;
uint8_t homePage_StartButton = 0;
uint8_t homePage_StopButton = 0;

bool GotoStopSent = false;   // Flag to ensure GotoStop command is sent only once
bool GotoStartSent = false;  // Flag to ensure GotoStart command is sent only once
volatile bool commandReceived = false;

//============================================ISR to handle UART data reception==========================================
ISR(USART_RX_vect) {
  uint8_t receivedByte = UDR0;
  UART_send(receivedByte);
  if (idx < BUFFER_SIZE) {
    commandBuffer[idx++] = receivedByte;
    commandReceived = true;
  } else {
    idx = 0;  // Reset index or handle overflow
  }
}
//========================================Function to initialize UART=======================================//
void UART_Begin() {
  UBRR0 = 8;  // For F_CPU = 16MHz, UBRR = 8 (baud rate for 115200bps)
  // Set frame format: 8 data bits, 1 stop bit
  UCSR0C |= (1 << UCSZ01) | (1 << UCSZ00);
  // Enable receiver, transmitter, and RX interrupt
  UCSR0B |= (1 << RXEN0) | (1 << TXEN0) | (1 << RXCIE0);
}
//=======================================Send a debug message via UART=================================================//
void sendDebugMessage(const char *message) {
  while (*message) {
    UART_send(*message++);
  }
}
//==========================================UART Send============================================================//
void UART_send(char data) {
  while (!(UCSR0A & (1 << UDRE0)))  // Waits until the transmit buffer is empty (UDRE0 flag is set) before sending the data.
    ;
  UDR0 = data;
}
//======================================Process commands received via UART=========================================//
void processCommands() {
  if (commandReceived) {
    commandReceived = false;
    handleCommand();
    idx = 0;
    memset(commandBuffer, 0, sizeof(commandBuffer));
  }
}
//======================================Handle commands based on the received buffer=================================//
void handleCommand() {
  char debugMsg[BUFFER_SIZE + 1];
  strncpy(debugMsg, (char *)commandBuffer, BUFFER_SIZE);
  debugMsg[BUFFER_SIZE] = '\0';  // Ensure null termination
  sendDebugMessage("Received Data: ");
  sendDebugMessage(debugMsg);

  //================================= Check for StartButton command=================================================//
  c = strstr((char *)commandBuffer, (char *)StartButton);
  if (c != NULL) {
    index = c - (char *)commandBuffer;
    //sendDebugMessage("StartButton command found!\n");
    if (minSet && secSet) {
      statements = 1;             // Start motor
      previousMillis = millis();  // Reset timing
      sendDebugMessage("Start button detected, starting motor...\n");
      if (!GotoStopSent) {
        sendDebugMessage("Sending GotoStop command...\n");
        for (size_t i = 0; i < sizeof(GotoStop); ++i) {
          UART_send(GotoStop[i]);
        }
        GotoStopSent = true;    // GotoStop command is sent only once
        GotoStartSent = false;  // Reset GotoStart flag
      }
    } else {
     sendDebugMessage("\nError: SetMin and SetSec values must be set before starting the motor.\n");
        if (!GotoStopSent) {
      sendDebugMessage("\n...Stop Button...\n");
        for (size_t i = 0; i < sizeof(GotoStop); ++i) {
          UART_send(GotoStop[i]);
        }
        GotoStopSent = true;    // GotoStop command is sent only once
        GotoStartSent = false;  // Reset GotoStart flag
      }     
      statements = 0;
    }
  }

  //=============================Check for StopButton command===========================================//
  c = strstr((char *)commandBuffer, (char *)StopButton);
  if (c != NULL) {
    index = c - (char *)commandBuffer;
   // sendDebugMessage("\nStopButton command found!\n");
    statements = 2;  // Stop motor
    sendDebugMessage("Stop button detected, stopping motor...\n");
    if (!GotoStartSent) {
      sendDebugMessage("\nSending GotoStart command...\n");
      for (size_t i = 0; i < sizeof(GotoStart); i++) {
        UART_send(GotoStart[i]);
      }
      GotoStartSent = true;  // GotoStart command is sent only once
      GotoStopSent = false;  // Reset GotoStop flag

    }
    minSet = false;
    secSet = false;
  }


  //===================================== Check for SetSec command==================================================//
  c = strstr((char *)commandBuffer, (char *)SetSec);
  if (c != NULL) {
    index = c - (char *)commandBuffer;
  //  sendDebugMessage("SetSec command found!\n");
    if ((commandBuffer[index - 1] == 0x83) && (commandBuffer[index + 1] == SetSec[1])) {
      uint8_t size = commandBuffer[index + 4];
      if (index + 4 + size <= BUFFER_SIZE) {
        uint8_t tempSetSec[10];
        for (uint8_t i = 0; i < size; i++) {
          tempSetSec[i] = commandBuffer[index + 5 + i];
        }
        homePage_setSec = 0;
        for (uint8_t i = 0; i < size; i++) {
          homePage_setSec = homePage_setSec * 10 + (tempSetSec[i] - '0');
        }
     //   sendDebugMessage("\nProcessed SetSec data...\n");
        char data[30];
        sprintf(data, "data Seconds:%d \n", homePage_setSec);
        sendDebugMessage(data);

        secSet = true;
      }
    }
  }

  //=========================================== Check for SetMin command====================================================//
  c = strstr((char *)commandBuffer, (char *)SetMin);
  if (c != NULL) {
    index = c - (char *)commandBuffer;
  //  sendDebugMessage("SetMin command found!\n");
    if ((commandBuffer[index - 1] == 0x83) && (commandBuffer[index + 1] == SetMin[1])) {
      uint8_t size = commandBuffer[index + 4];
      if (index + 4 + size <= BUFFER_SIZE) {
        uint8_t tempSetMin[10];
        homePage_setMin = 0;
        for (uint8_t i = 0; i < size; i++) {
          tempSetMin[i] = commandBuffer[index + 5 + i];
        }
        for (uint8_t i = 0; i < size; i++) {
          homePage_setMin = homePage_setMin * 10 + (tempSetMin[i] - '0');
        }
   //     sendDebugMessage("\nProcessed SetMin data...\n");
        char data[30];
        sprintf(data, "data minutes:%d \n", homePage_setMin);
        sendDebugMessage(data);

        minSet = true;
      }
    }
  }
}
