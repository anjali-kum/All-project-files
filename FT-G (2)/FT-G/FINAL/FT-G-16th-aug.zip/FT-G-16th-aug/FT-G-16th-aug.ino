#include "MotorControl.h"
#include "UARTHandler.h"

void setup() {
  // Initialize motor control pins
  pinMode(stepPin, OUTPUT);
  pinMode(dirPin, OUTPUT);
  pinMode(enPin, OUTPUT);
  digitalWrite(enPin, LOW);

  UART_Begin();

  //sendDebugMessage("\nFT-G\n");

  sei();  // Enable global interrupts
}

void loop() {

  processCommands();

  switch (statements) {
    case 1:
      if (minSet && secSet) {
        setMotorRunDuration(homePage_setMin, homePage_setSec);  // Set duration
        startMotor();
        updateTiming();
      } else {
        sendDebugMessage("Error: SetMin and SetSec values must be set before starting the motor.\n");
        statements = 0;
      }
      break;
    case 2:
      if (motorRunning) {
        stopMotor();
        statements = 0;
      }
      break;
    default:
      // Reset flags for a fresh start attempt
      GotoStopSent = false;
      GotoStartSent = false;
      break;
  }
}
