#include "MotorControl.h"
#include "UARTHandler.h"
#include <Arduino.h>

const int stepPin = 5;
const int dirPin = 2;
const int enPin = 8;

bool motorRunning = false;
unsigned long previousMillis = 0;
unsigned long runDuration = 0;

uint8_t GotoStartt[] = { 0x5A, 0xA5, 0x07, 0x82, 0x00, 0x84, 0x5A, 0x01, 0x00, 0x00 };

bool minSet = false;
bool secSet = false;

void startMotor() {
  static bool motorStarted = false;
  if (!motorStarted) {
    const char *startMsg = "Stepper motor starting...\n";
    sendDebugMessage(startMsg);

    motorStarted = true;
  }

  digitalWrite(dirPin, HIGH);      // Set the direction to clockwise
  digitalWrite(enPin, LOW);        // Enable the driver
  for (int i = 0; i < 400; i++) {  // homePage_speed
    digitalWrite(stepPin, HIGH);
    delayMicroseconds(500);
    digitalWrite(stepPin, LOW);
    delayMicroseconds(500);
  }
 // sendDebugMessage("Motor started. Timing reset.\n");
}

void stopMotor() {
  static bool motorStopped = false;
  if (!motorStopped) {
    const char *stopMsg = "Stepper motor stopping...\n";
    sendDebugMessage(stopMsg);

    motorStopped = true;
  }

  motorRunning = false;
  digitalWrite(stepPin, LOW);  //motor stops
  sendDebugMessage("Motor stopped.\n");

  sendDebugMessage((char *)(GotoStart));
  sendDebugMessage((char *)(GotoStart));
}

void updateTiming() {

  unsigned long currentTime = millis();
  unsigned long elapsedTime = currentTime - previousMillis;

  //check timing
  char debugMsg[50];
  snprintf(debugMsg, sizeof(debugMsg), "Elapsed Time: %lu ms, Run Duration: %lu ms\n", elapsedTime, runDuration);
  sendDebugMessage(debugMsg);


  if (elapsedTime >= runDuration) {
    stopMotor();

    for (size_t i = 0; i < sizeof(GotoStartt); i++) {
      UART_send(GotoStartt[i]);
    }

    for (size_t i = 0; i < sizeof(GotoStartt); i++) {
      UART_send(GotoStartt[i]);
    }
    statements = 2;
    minSet = false;
    secSet = false;
  }
}
unsigned long millisToSeconds(unsigned long millis) {
  return millis / 1000;
}

unsigned long millisToMinutes(unsigned long millis) {
  return millis / 60000;
}

void setMotorRunDuration(unsigned int minutes, unsigned int seconds) {
  runDuration = (minutes * 60000) + (seconds * 1000);

  char debugMsg[50];
  snprintf(debugMsg, sizeof(debugMsg), "Run Duration Set: %lu ms\n", runDuration);
  sendDebugMessage(debugMsg);
}
